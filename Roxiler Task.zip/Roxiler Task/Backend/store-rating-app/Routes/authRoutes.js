// routes/authRoutes.js
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Route to render the login page
router.get('/login', (req, res) => {
  res.render('login');
});

// Route to handle login
router.post('/login', authController.login);

// Route to render the signup page
router.get('/signup', (req, res) => {
  res.render('signup');
});

// Route to handle sign up
router.post('/signup', authController.signUp);

module.exports = router;
