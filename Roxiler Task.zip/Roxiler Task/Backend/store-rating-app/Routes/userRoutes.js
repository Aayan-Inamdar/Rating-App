const express = require('express');
const { loginUser, renderLoginPage } = require('../controllers/userController');

const router = express.Router();

// Render the login page (initial request)
router.get('/login', renderLoginPage);

// Handle login POST request
router.post('/login', loginUser);

module.exports = router;
