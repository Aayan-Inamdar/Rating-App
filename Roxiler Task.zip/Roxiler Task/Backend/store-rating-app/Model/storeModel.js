const mongoose = require('mongoose');

// Store schema
const storeSchema = new mongoose.Schema({
    name: String,
    address: String,
    overallRating: {
        type: Number,
        default: 0
    }
});

// Create a Store model
const Store = mongoose.model('Store', storeSchema);

module.exports = Store;
