const Store = require('../models/storeModel');

// Add a new store
exports.addStore = async (req, res) => {
    try {
        const { name, address } = req.body;
        const newStore = new Store({ name, address });

        await newStore.save();
        res.status(201).json({ message: 'Store added successfully' });
    } catch (err) {
        res.status(500).json({ message: 'Error adding store', error: err });
    }
};

// Get store details
exports.getStore = async (req, res) => {
    try {
        const store = await Store.findOne({ _id: req.params.storeId });
        if (!store) return res.status(404).json({ message: 'Store not found' });

        res.render('storeRating', { store });  // Renders the storeRating.ejs template
    } catch (err) {
        res.status(500).json({ message: 'Error fetching store', error: err });
    }
};
