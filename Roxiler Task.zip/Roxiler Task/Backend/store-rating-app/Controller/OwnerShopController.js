const Store = require('../models/storeModel');

const createStore = async (req, res) => {
    const { name, email, address, password } = req.body;
    try {
        const store = new Store({ name, email, address });
        await store.save();
        res.render('storeDetail', { store, success: 'Store created successfully!' });
    } catch (err) {
        console.error(err);
        res.render('storeDetail', { error: 'Error creating store. Please try again.' });
    }
};

const getStoreById = async (req, res) => {
    try {
        const store = await Store.findById(req.params.id);
        res.render('storeDetail', { store });
    } catch (err) {
        console.error(err);
        res.render('storeDetail', { error: 'Store not found.' });
    }
};

const listStores = async (req, res) => {
    try {
        const stores = await Store.find();
        res.render('storeList', { stores });
    } catch (err) {
        console.error(err);
        res.render('storeList', { error: 'Error fetching stores.' });
    }
};

module.exports = { createStore, getStoreById, listStores };
