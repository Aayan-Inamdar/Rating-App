const User = require('../models/User');

exports.signupPage = (req, res) => {
  res.render('signup');
};

exports.loginPage = (req, res) => {
  res.render('login');
};

exports.signup = (req, res) => {
  const { username, password, email } = req.body;
  // Validation and saving logic
  const newUser = new User({ username, password, email });
  newUser.save()
    .then(() => res.redirect('/login'))
    .catch(err => res.status(500).send(err));
};

exports.login = (req, res) => {
  const { username, password } = req.body;
  // Authentication logic
  User.findOne({ username, password })
    .then(user => {
      if (user) {
        req.session.user = user;
        res.redirect('/home');
      } else {
        res.redirect('/login');
      }
    })
    .catch(err => res.status(500).send(err));
};
