const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Login User
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Create JWT token
    const token = jwt.sign({ id: user._id }, 'your_jwt_secret', { expiresIn: '1h' });

    // Send response with token
    res.json({ token });

  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Render login page with error (if any)
const renderLoginPage = (req, res) => {
  res.render('login', { error: null });
};

module.exports = { loginUser, renderLoginPage };
