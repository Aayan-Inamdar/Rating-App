const Store = require('../models/Store');

exports.dashboardPage = (req, res) => {
  res.render('dashboard');
};

exports.createNewStore = (req, res) => {
  const { storeName, owner } = req.body;
  // Saving store logic
  const newStore = new Store({ storeName, owner });
  newStore.save()
    .then(() => res.redirect('/dashboard'))
    .catch(err => res.status(500).send(err));
};
