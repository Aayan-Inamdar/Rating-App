// controllers/authController.js
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Admin Sign Up Controller
exports.signUp = async (req, res) => {
  const { name, email, address, password } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).render('signup', { error: 'Email already exists.' });
    }

    const user = new User({ name, email, address, password });
    await user.save();

    res.status(201).render('login', { success: 'Account created successfully!' });
  } catch (error) {
    res.status(500).render('signup', { error: 'Error signing up. Please try again.' });
  }
};

// Admin Login Controller
exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).render('login', { error: 'Invalid email or password.' });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).render('login', { error: 'Invalid email or password.' });
    }

    // Generate JWT Token
    const token = jwt.sign({ userId: user._id }, 'your_secret_key', { expiresIn: '1h' });

    res.cookie('token', token, { httpOnly: true });
    res.redirect('/dashboard'); // Redirect to a protected page
  } catch (error) {
    res.status(500).render('login', { error: 'Error logging in. Please try again.' });
  }
};
