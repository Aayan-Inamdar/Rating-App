import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom'; // Corrected import
import Navbar from './Components/Navbar';
import NormalUserPage from './Components/StoreDetail';
import Signup from './Components/Signup';
import Login from './Components/Login';
import RatingForm from './Components/RatingForm';
import Dashboard from './Components/Dashboard';
import NormalUsers from './Components/NormalUsers';
import Admin from './Components/Admin';
import SignUpNewStore from './Components/SignUpNewStore';
import UserSignUP from './Components/UserSignUP';
import AdminSignUp from './Components/AdminSignUp';
import Home from './Components/Home';

function App() {
  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
          <Route path="/normaluser" element={<NormalUserPage />} />
          <Route path="/RatingForm" element={<RatingForm />} />
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/NormalUsers" element={<NormalUsers />} />
          <Route path="/Admin" element={<Admin />} />
          <Route path="/SignUpNewStore" element={<SignUpNewStore />} />
          <Route path="/UserSignUP" element={<UserSignUP />} />
          <Route path="/AdminSignUp" element={<AdminSignUp />} />
          <Route path="/Home" element={<Home />} />
        </Routes>

        <div className="container" style={{ padding: '0', margin: '0' }}>
          <div
            className="row"
            style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              minHeight: '100vh',
            }}
          >
            {/* Normal User Box */}
            <div className="col-md-3 mb-4" style={{ marginBottom: '20px' }}>
              <div
                className="box user-box text-center"
                style={{
                  border: '2px solid #007bff',
                  borderRadius: '8px',
                  backgroundColor: '#e9ecef',
                  padding: '20px',
                  boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.3s ease',
                }}
              >
                <img
                  src="https://cdn-icons-png.flaticon.com/512/9385/9385289.png"
                  alt="User"
                  className="logo mb-3"
                  style={{
                    width: '100px',
                    height: '100px',
                    objectFit: 'cover',
                    marginBottom: '15px',
                  }}
                />
                <h4 style={{ color: '#007bff', fontSize: '1.2rem' }}>Normal User</h4>
                {/* Login and SignUp Buttons */}
                <Link
                  to="/login"
                  style={{
                    marginTop: '10px',
                    padding: '10px 20px',
                    backgroundColor: '#007bff',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    marginBottom: '10px',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#28a745',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Sign Up
                </Link>
              </div>
            </div>

            {/* Store Owner Box */}
            <div className="col-md-3 mb-4" style={{ marginBottom: '20px' }}>
              <div
                className="box store-owner-box text-center"
                style={{
                  border: '2px solid #007bff',
                  borderRadius: '8px',
                  backgroundColor: '#d1ecf1',
                  padding: '20px',
                  boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.3s ease',
                }}
              >
                <img
                  src="https://static.vecteezy.com/system/resources/previews/020/662/327/large_2x/store-icon-logo-illustration-vector.jpg"
                  alt="Store Owner"
                  className="logo mb-3"
                  style={{
                    width: '100px',
                    height: '100px',
                    objectFit: 'cover',
                    marginBottom: '15px',
                  }}
                />
                <h4 style={{ color: '#007bff', fontSize: '1.2rem' }}>Store Owner</h4>
                {/* Login and SignUp Buttons */}
                <Link
                  to="/Dashboard"
                  style={{
                    marginTop: '10px',
                    padding: '10px 20px',
                    backgroundColor: '#007bff',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    marginBottom: '10px',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Login
                </Link>
                <Link
                  to="/SignUpNewStore"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#28a745',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Sign Up
                </Link>
              </div>
            </div>

            {/* Admin Panel Box */}
            <div className="col-md-3 mb-4" style={{ marginBottom: '20px' }}>
              <div
                className="box admin-panel-box text-center"
                style={{
                  border: '2px solid #007bff',
                  borderRadius: '8px',
                  backgroundColor: '#f8d7da',
                  padding: '20px',
                  boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.3s ease',
                }}
              >
                <img
                  src="https://cdn-icons-png.flaticon.com/512/2304/2304226.png"
                  alt="Admin Panel"
                  className="logo mb-3"
                  style={{
                    width: '100px',
                    height: '100px',
                    objectFit: 'cover',
                    marginBottom: '15px',
                  }}
                />
                <h4 style={{ color: '#007bff', fontSize: '1.2rem' }}>Admin Panel</h4>
                {/* Login and SignUp Buttons */}
                <Link
                  to="/Admin"
                  style={{
                    marginTop: '10px',
                    padding: '10px 20px',
                    backgroundColor: '#007bff',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    marginBottom: '10px',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Login
                </Link>
                <Link
                  to="/AdminSignUp"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#28a745',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer',
                    width: '100%',
                    textDecoration: 'none',
                    display: 'inline-block',
                    textAlign: 'center',
                  }}
                >
                  Sign Up
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
