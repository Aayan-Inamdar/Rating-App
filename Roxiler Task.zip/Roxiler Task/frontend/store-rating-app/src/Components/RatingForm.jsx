
import React, { useState } from "react";

// StoreRating Component
const StoreRating = () => {
  // States for rating system
  const [userRating, setUserRating] = useState(0); // The rating the user wants to submit
  const [submittedRating, setSubmittedRating] = useState(3); // The rating user has submitted (initially 3)
  const [modifiedRating, setModifiedRating] = useState(0); // The rating user wants to modify
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Simulates the login status

  // Sample store data
  const store = {
    name: "mollchand mill",
    address: "Hadapsar Pune ",
    overallRating: 4.2, // Static overall rating
  };

  // Function to handle rating change
  const handleRatingChange = (e) => {
    setUserRating(Number(e.target.value));
  };

  // Function to submit the rating
  const handleSubmitRating = (e) => {
    e.preventDefault();
    setSubmittedRating(userRating);
  };

  // Function to handle modifying the rating
  const handleModifyRating = (e) => {
    e.preventDefault();
    setSubmittedRating(modifiedRating);
  };

  // Function to log out
  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <div className="container mt-5">
      {isLoggedIn ? (
        <>
          <h2>Store Rating</h2>
          <div className="card">
            <div className="card-body">
              <h3>{store.name}</h3>
              <p>
                <strong>Address:</strong> {store.address}
              </p>
              <p>
                <strong>Overall Rating:</strong> {store.overallRating} / 5
              </p>

              {/* Display user's submitted rating */}
              <p>
                <strong>Your Rating:</strong> {submittedRating} / 5
              </p>

              {/* Rating form for submitting new rating */}
              <div className="star-rating">
                <label className="d-block mb-2">Submit Your Rating:</label>
                {[5, 4, 3, 2, 1].map((star) => (
                  <React.Fragment key={star}>
                    <input
                      type="radio"
                      id={`star${star}`}
                      name="rating"
                      value={star}
                      onChange={handleRatingChange}
                      className="star-input"
                    />
                    <label htmlFor={`star${star}`} className="star-label">
                      ★
                    </label>
                  </React.Fragment>
                ))}
              </div>
              <button
                className="btn btn-primary mt-3"
                onClick={handleSubmitRating}
              >
                Submit Rating
              </button>

              {/* Modify rating section */}
              <div className="mt-4">
                <button
                  className="btn btn-warning"
                  data-bs-toggle="modal"
                  data-bs-target="#modifyRatingModal"
                >
                  Modify Your Rating
                </button>
              </div>

              {/* Log Out Button */}
              <div className="mt-3">
                <button
                  className="btn btn-danger"
                  onClick={handleLogout}
                >
                  Log Out
                </button>
              </div>
            </div>
          </div>

          {/* Modal to Modify Rating */}
          <div
            className="modal fade"
            id="modifyRatingModal"
            tabIndex="-1"
            aria-labelledby="modifyRatingModalLabel"
            aria-hidden="true"
          >
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="modifyRatingModalLabel">
                    Modify Your Rating
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  ></button>
                </div>
                <div className="modal-body">
                  <div className="star-rating">
                    {[5, 4, 3, 2, 1].map((star) => (
                      <React.Fragment key={star}>
                        <input
                          type="radio"
                          id={`star${star}_modify`}
                          name="modify_rating"
                          value={star}
                          onChange={(e) => setModifiedRating(Number(e.target.value))}
                          className="star-input"
                        />
                        <label htmlFor={`star${star}_modify`} className="star-label">
                          ★
                        </label>
                      </React.Fragment>
                    ))}
                  </div>
                  <button
                    type="button"
                    className="btn btn-primary mt-3"
                    onClick={handleModifyRating}
                  >
                    Submit Modified Rating
                  </button>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center mt-5">
          <h4>You have logged out successfully.</h4>
          <button
            className="btn btn-primary"
            onClick={() => setIsLoggedIn(true)}
          >
            Log In Again
          </button>
        </div>
      )}
    </div>
  );
};

export default StoreRating;

