// src/components/StoreDetail.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StoreDetail = ({ match }) => {
  const [store, setStore] = useState(null);

  useEffect(() => {
    // Fetch store details based on ID
    axios.get(`http://localhost:5000/api/stores/${match.params.id}`)
      .then(response => setStore(response.data))
      .catch(error => console.error('Error fetching store details:', error));
  }, [match.params.id]);

  if (!store) return <div>Loading...</div>;

  return (
    <div className="container">
      <h2>{store.name}</h2>
      <p>{store.address}</p>
      <p>Rating: {store.rating}</p>
    </div>
  );
};

export default StoreDetail;
