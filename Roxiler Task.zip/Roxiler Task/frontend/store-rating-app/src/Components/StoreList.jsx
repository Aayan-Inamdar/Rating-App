// src/components/StoreList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StoreList = () => {
  const [stores, setStores] = useState([]);

  useEffect(() => {
    // Fetch stores from the backend
    axios.get('http://localhost:5000/api/stores')
      .then(response => setStores(response.data))
      .catch(error => console.error('Error fetching stores:', error));
  }, []);

  return (
    <div className="container">
      <h2>Store List</h2>
      <div className="list-group">
        {stores.map(store => (
          <div key={store.id} className="list-group-item">
            <h5>{store.name}</h5>
            <p>{store.address}</p>
            <p>Rating: {store.rating}</p>
            <a href={`/store/${store.id}`} className="btn btn-primary">View Store</a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StoreList;
